#!/usr/bin/env python
# -*- coding: utf-8 -*-

try:
    pass
except ImportError:
    raise ImportError('You don t have the package ... installed. Try pip install ....')

def func(foo, bar):
	pass
